# BBS Site App — Deployment Guide

This is a standalone version of your BBS Calculator app, ready to put on the real internet
(outside Claude entirely) so downloads and everything else works like a normal website.

## The easiest way: Vercel (free, no credit card, ~10 minutes)

1. Go to https://vercel.com and sign up (you can sign up with just an email or a GitHub account).
2. Once logged in, click **"Add New" → "Project"**.
3. Choose **"Deploy without Git"** or **"Upload"** (Vercel supports dragging a folder straight in)
   — drag this entire project folder onto the page.
   - If Vercel asks for Git instead: create a free GitHub account at https://github.com,
     create a new repository, upload these files there (GitHub's website has an "upload files"
     button — no command line needed), then connect that repository to Vercel.
4. Vercel will detect this is a Vite + React project automatically. Just click **Deploy**.
5. After a minute, you'll get a real URL like `https://bbs-site-app.vercel.app` —
   that's your live, public app. Share that link with anyone.

## Alternative: Netlify (also free, drag-and-drop)

1. Go to https://app.netlify.com/drop
2. First run these two commands on any computer with Node.js installed:
   ```
   npm install
   npm run build
   ```
3. Drag the resulting `dist` folder onto the Netlify Drop page. Done — you get a live URL instantly.

## Important: what changes once it's a real website

- **Downloads will work normally** — this was the whole point. A real website isn't run through
  Claude's app, so there's no download-blocking layer anymore.
- **Data storage changes**: this version saves Site Records and Daily Progress Reports to each
  visitor's own browser (`localStorage`), not to a shared central database. That means:
  - Your data on your phone won't show up on a colleague's phone.
  - Each person who uses the app has their own separate saved records.
  - This is fine for a personal tool, but **not** enough for a true shared team/customer database.

## If you want everyone to see the same shared data (a real backend)

That needs a proper database, not just a website. The standard free options are:
- **Supabase** (https://supabase.com) — free tier, easiest to add to a React app like this one.
- **Firebase** (https://firebase.google.com) — also free tier, very popular for exactly this.

This is a bigger step (adding real user accounts, a database, and security rules) — if you want
this, come back and tell me, and I'll help you build that layer on top of this same app.

## Enabling real Team Chat across devices (optional, ~5 minutes)

Without this step, the "Team Chat" tab still works, but messages only appear on the same
phone/browser that sent them — not shared with anyone else. To make chat actually work
between different people's phones, set up a free Firebase project:

1. Go to https://console.firebase.google.com → **Add project** → give it any name → skip Analytics if asked.
2. Once created, click the **`</>`** (web) icon to add a web app → give it a nickname → **Register app**.
3. Firebase shows a code snippet with a `firebaseConfig` object (apiKey, authDomain, projectId, etc.) — copy those values.
4. In the left sidebar, go to **Build → Firestore Database → Create database** → choose **Start in test mode** → pick any location → **Enable**.
5. Open `src/App.jsx` in this project, find `FIREBASE_CONFIG` near the top, and paste your values in:
   ```js
   const FIREBASE_CONFIG = {
     apiKey: "your-value-here",
     authDomain: "your-value-here",
     projectId: "your-value-here",
     storageBucket: "your-value-here",
     messagingSenderId: "your-value-here",
     appId: "your-value-here",
   };
   ```
6. Commit that change on GitHub → Vercel redeploys → Team Chat now works live across everyone's devices.

**Security note:** "test mode" Firestore rules are open to anyone for 30 days by default — fine to
try this out, but if you keep using it, tighten the rules in Firebase Console → Firestore → Rules
before real project data goes in there.



If you or someone technical wants to test it on a computer first:
```
npm install
npm run dev
```
Then open the URL it shows (usually `http://localhost:5173`) in a browser.
